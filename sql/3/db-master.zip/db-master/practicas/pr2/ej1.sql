select nombrecompleto from votantes
where nombrecompleto like '% % %n';