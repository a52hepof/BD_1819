select  dni "dni", nombrecompleto "nombre" from votantes
where dni like '%5%5%5%'