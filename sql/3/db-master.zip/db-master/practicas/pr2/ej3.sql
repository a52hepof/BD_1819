select nombrecompleto "nombre" from votantes
where votantes.fechanacimiento >= '01/01/1990';