drop table consultas_datos;
drop table consultas;
drop table votantes;
