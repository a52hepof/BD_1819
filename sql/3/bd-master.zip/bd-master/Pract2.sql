-- Ejercicio 1

select nombrecompleto 
from votantes 
where nombrecompleto like '%n';

-- Ejercicio 2

select dni 
from votantes 
where dni like '%5%5%5%';

-- Ejercicio 3

select nombrecompleto 
from votantes 
where fechanacimiento > '01/01/1990';

-- Ejercicio 4

select a.nombrecompleto, b.nombre 
from votantes a join localidades b on b.idlocalidad=a.localidad 
where b.numerohabitantes > 300000;

-- Ejercicio 5

select a.nombrecompleto, c.comunidad 
from votantes a join localidades b on a.localidad=b.idlocalidad join provincias c on b.provincia=c.idprovincia 
where b.numerohabitantes > 300000;

-- Ejercicio 6

select partido, count(partido) as conteo 
from consultas_datos 
group by partido;

-- Ejercicio 7

select partido, count(partido) 
from consultas_datos 
group by partido;

-- Ejercicio 8

select b.nombrecompleto 
from consultas_datos a join partidos b on a.partido=b.idpartido 
having count(a.partido) > 10
group by b.nombrecompleto;

-- Ejercicio 9

select b.nombrecompleto, count(a.partido) as conteo 
from consultas_datos a join partidos b on a.partido=b.idpartido 
having count(a.partido) > 10 
group by b.nombrecompleto;

-- Ejercicio 10

select b.nombrecompleto, count(a.partido) as conteo 
from consultas_datos a join partidos b on a.partido=b.idpartido 
where a.respuesta like 'Si' and a.certidumbre > 0.8
group by b.nombrecompleto;

----------------