select idpartido, siglas, presidente from partidos;
select idpartido "IDENTIFICADOR", siglas, presidente from partidos;

select localidades.nombre "Nombre de localidades", localidades.numerohabitantes "N� de habitantes localidades", provincias.nombre "Nombre de provincias", provincias.numerohabitantes "N� de habitantes provincias" from provincias, localidades;
select l.nombre "Nombre de localidades", l.numerohabitantes "N� de habitantes localidades", p.nombre "Nombre de provincias", p.numerohabitantes "N� de habitantes provincias" from provincias p, localidades l;

--ejercicio2
select table_name from user_tables;

--ejercicio 3
describe partidos;
describe provincias;
describe localidades;
describe votantes;
describe eventos; 
describe eventos_resultados;
describe consultas;
describe consultas_datos;

--ejercicio 4 (quitar comentario para que funcione)
drop table votantes;
--drop table votantes cascade constraints; 

--ejercicio 5
insert into votantes values (
30653845,
'Maria Gonzalez Ramirez',
'Doctorado',
'Activo',
'goram@telefonica.es',
1,
'21/08/1989',
677544822
); 
--ejercicio 6
select * from votantes;

--ejercicio 7
delete from votantes where dni=30653845;
select * from votantes; 

--ejercicio 9
select nombre, tipo, fecha from eventos;

--ejercicio 10
select nombre||' de tipo '||tipo "Convocatorias" from eventos; 

--ejercicio 11
select localidades.nombre||', '||provincias.nombre "Ciudades" from localidades, provincias; 